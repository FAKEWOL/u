<h3>Wamp Server Aktif Etme </h3>

<p>Windows Tuşuna Basıp "Wamp" Yazın ve Programı Yönetici Olarak Çalıştırın</p>

![w1](https://github.com/user-attachments/assets/b434df7b-33a4-442b-b8e5-493cfc6f1421) <br>

<p>Sağ Aşağıda Bulunan Wamp Sekmesini Açın</p>

![w2](https://github.com/user-attachments/assets/6a2239fe-127c-485d-993b-9bc4270cfc18) <br>

<p> Offline Kısmını Online Hale Getirin</p>

![w4](https://github.com/user-attachments/assets/173de6dc-5415-4a59-b1a3-bb37aaaaec06)

<p>Mysql Notifer Kısmıdan 80 sürümünü kapatıp 64 sürümünü açın</p>

![w3](https://github.com/user-attachments/assets/77b91f04-700e-4de7-9b94-f7a0ce817ca6)

<p>Sonuç Olarak Böyle Gözükmesi Lazım</p>

![w5](https://github.com/user-attachments/assets/6a6fceb8-1939-45c0-8f07-d9ebfec5ed00)

<p>En Son Olarak Wamp Sekmesine Gelip "phpMyAdmin'e Tıklayın"</p>

![w6](https://github.com/user-attachments/assets/407da957-c282-4ab3-9cda-c8f920e03104)
