* İlk Wamp Serveri Açıp Sonra Veri Tabanını Aktarın
* normal localhost'da Hata Veriyor localhost:90'da deneyin
