<h3>phpMyAdmin Veri Tabanı Ekleme</h3>
<br>

<p>Sol Üst Kısımdaki Yeni Yazısına Tıklayarak Yeni Veri Tabanı Oluşturunuz</p>

![1](https://github.com/user-attachments/assets/5b5e281c-6252-4a9c-a60f-f0a3cfafb861) <br>
<p>Veri Tabanını Oluşturmak İçin Veri Tabanına Bir İsim Veriniz "Dersdb"</p>

![2](https://github.com/user-attachments/assets/642da94e-45d7-4e12-bb13-3b38a729ec4e) <br>
<p>Veri Tabanını Oluşturduktan Sonra İçine Girip İçe Aktar'a Tıklayın</p>

![3](https://github.com/user-attachments/assets/4d2c3859-989e-4b93-95e6-ecbd56ca3c63) <br>
<p>İçe Aktar Sayfasına Geldikten Sonra Dosya Seç Butonuna Tıklayıp Veri Tabanını Şeçiniz </p>

![4](https://github.com/user-attachments/assets/d5f5398b-de80-4406-848c-1fdb55ad14d1) <br>
<p>Veri Tabanı İsmi:127_0_0_1 Tıklayıp Veri Tabanına Aktarın</p>

![5](https://github.com/user-attachments/assets/f254964c-c04b-4c5d-83bf-e6d098360029)

<p>Sonuc</p>

![6](https://github.com/user-attachments/assets/f9c55cc0-a5d6-4c81-b2de-ae06e75b996f) <br>

![7](https://github.com/user-attachments/assets/0e338301-708b-4151-9de0-3a44d6c89c4a)
